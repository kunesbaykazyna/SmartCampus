import { describe, expect, it } from 'vitest';
import {
  filterByCapacity,
  filterByEquipment,
  filterOutBlocked,
  filterRooms,
  findRoomById,
} from '@/lib/filtering';
import { ROOMS } from '@/lib/rooms';
import { type Room } from '@/lib/booking';

const makeRoom = (overrides: Partial<Room> = {}): Room => ({
  id: 'r-test',
  name: 'Test Room',
  building: 'Test Block',
  capacity: 10,
  type: 'Test',
  equipment: ['Whiteboard'],
  blocked: false,
  imageUrl: '',
  bookings: [],
  ...overrides,
});

describe('F1 — capacity filter', () => {
  const rooms = [
    makeRoom({ id: 'a', capacity: 5 }),
    makeRoom({ id: 'b', capacity: 10 }),
    makeRoom({ id: 'c', capacity: 20 }),
  ];

  it('keeps rooms that meet or exceed the requested capacity', () => {
    expect(filterByCapacity(rooms, 10).map((r) => r.id)).toEqual(['b', 'c']);
  });

  it('returns all rooms when minimum is zero', () => {
    expect(filterByCapacity(rooms, 0).map((r) => r.id)).toEqual(['a', 'b', 'c']);
  });

  it('returns an empty array when no room is large enough', () => {
    expect(filterByCapacity(rooms, 25)).toEqual([]);
  });
});

describe('F2 — equipment filter', () => {
  const rooms = [
    makeRoom({ id: 'a', equipment: ['Projector'] }),
    makeRoom({ id: 'b', equipment: ['Projector', 'Microphone'] }),
    makeRoom({ id: 'c', equipment: ['Whiteboard', 'Microphone'] }),
  ];

  it('returns all rooms when no equipment is required', () => {
    expect(filterByEquipment(rooms, []).map((r) => r.id)).toEqual(['a', 'b', 'c']);
  });

  it('keeps only rooms containing ALL required items', () => {
    expect(filterByEquipment(rooms, ['Projector', 'Microphone']).map((r) => r.id)).toEqual(['b']);
  });

  it('returns an empty array when no room has all required items', () => {
    expect(filterByEquipment(rooms, ['Projector', 'Microphone', 'Smart TV'])).toEqual([]);
  });
});

describe('F3 — blocked room filter', () => {
  const rooms = [
    makeRoom({ id: 'a', blocked: false }),
    makeRoom({ id: 'b', blocked: true, blockedReason: 'Maintenance' }),
  ];

  it('removes blocked rooms', () => {
    expect(filterOutBlocked(rooms).map((r) => r.id)).toEqual(['a']);
  });

  it('blocks a room even when a free time slot exists', () => {
    const blocked = makeRoom({
      id: 'x',
      blocked: true,
      blockedReason: 'Closed',
      bookings: [],
    });
    expect(filterOutBlocked([blocked])).toEqual([]);
  });
});

describe('F4 — empty state', () => {
  it('returns an empty array when no room matches the combined criteria', () => {
    expect(filterRooms(ROOMS, { minCapacity: 100, requiredEquipment: [] })).toEqual([]);
  });

  it('returns an empty array when required equipment is absent everywhere', () => {
    expect(
      filterRooms(ROOMS, { minCapacity: 0, requiredEquipment:['Nonexistent Device'] }),
    ).toEqual([]);
  });
});

describe('F5 — room selection refresh', () => {
  it('findRoomById returns the room with matching id', () => {
    expect(findRoomById(ROOMS, 'room-b204')?.id).toBe('room-b204');
  });

  it('findRoomById returns undefined for an unknown id', () => {
    expect(findRoomById(ROOMS, 'nope')).toBeUndefined();
  });

  it('each room has its own isolated booking array', () => {
    const ids = ROOMS.map((r) => r.id);
    const allBookingIds = ROOMS.flatMap((r) => r.bookings.map((b) => b.id));
    const uniqueIds = new Set(allBookingIds);
    expect(allBookingIds.length).toBe(uniqueIds.size);
    expect(ids).toEqual(['room-a301', 'room-b204', 'room-c110', 'room-d007']);
  });
});

describe('filterRooms — combined integration', () => {
  it('filters the catalog by capacity and equipment and excludes blocked rooms', () => {
    const result = filterRooms(ROOMS, { minCapacity: 16, requiredEquipment: ['Projector'] });
    expect(result.map((r) => r.id)).toEqual(['room-a301']);
  });

  it('includes multiple matching rooms', () => {
    const result = filterRooms(ROOMS, { minCapacity: 0, requiredEquipment: [] });
    expect(result.map((r) => r.id)).toEqual(['room-a301', 'room-b204', 'room-d007']);
  });
});
