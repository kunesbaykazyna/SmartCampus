import { describe, expect, it } from 'vitest';
import {
  evaluate,
  findConflict,
  fromClock,
  toClock,
  type Room,
  type Verdict,
} from '@/lib/booking';

const NOW = 500; // 08:20

const makeRoom = (overrides: Partial<Room> = {}): Room => ({
  id: 'room-test',
  name: 'Test Room',
  building: 'Test Block',
  capacity: 10,
  type: 'Seminar',
  equipment: ['Whiteboard'],
  blocked: false,
  imageUrl: '',
  bookings: [
    { id: 'b1', title: 'Calculus II', organizer: 'Prof. Tan', start: 540, end: 600 },
    { id: 'b2', title: 'Faculty Sync', organizer: 'Dean Office', start: 660, end: 720 },
    { id: 'b3', title: 'Robotics Lab', organizer: 'Prof. Lim', start: 780, end: 840 },
    { id: 'b4', title: 'Study Group', organizer: 'ACM Chapter', start: 900, end: 960 },
  ],
  ...overrides,
});

const deepFreeze = <T>(value: T): T => {
  if (value && typeof value === 'object') {
    Object.values(value).forEach(deepFreeze);
    Object.freeze(value);
  }
  return value;
};

const errorsOf = (verdict: Verdict): string[] => {
  if (verdict.kind !== 'error') throw new Error(`expected error, got ${verdict.kind}`);
  return verdict.messages;
};

describe('toClock / fromClock', () => {
  it('formats minutes as zero-padded HH:MM', () => {
    expect(toClock(0)).toBe('00:00');
    expect(toClock(545)).toBe('09:05');
    expect(toClock(1439)).toBe('23:59');
  });

  it('parses 24-hour HH:MM and rejects anything else', () => {
    expect(fromClock('09:00')).toBe(540);
    expect(fromClock('9:30')).toBe(570);
    expect(fromClock(' 13:30 ')).toBe(810);
    expect(fromClock('23:59')).toBe(1439);
    expect(fromClock('24:00')).toBeNull();
    expect(fromClock('12:60')).toBeNull();
    expect(fromClock('1pm')).toBeNull();
    expect(fromClock('')).toBeNull();
  });
});

describe('findConflict', () => {
  const bookings = makeRoom().bookings;

  it('treats touching endpoints as non-overlapping', () => {
    expect(findConflict(bookings, 600, 660)).toBeUndefined();
    expect(findConflict(bookings, 480, 540)).toBeUndefined();
  });

  it('detects partial, contained and enclosing overlaps', () => {
    expect(findConflict(bookings, 570, 630)?.id).toBe('b1');
    expect(findConflict(bookings, 545, 590)?.id).toBe('b1');
    expect(findConflict(bookings, 500, 700)?.id).toBe('b1');
  });
});

describe('evaluate: input validation', () => {
  const room = makeRoom();

  it('rejects a malformed start time', () => {
    expect(errorsOf(evaluate('25:00', 60, room, NOW))).toEqual([
      'Start time must be in 24-hour HH:MM format (e.g. 13:30).',
    ]);
    expect(errorsOf(evaluate('', 60, room, NOW))).toEqual([
      'Start time must be in 24-hour HH:MM format (e.g. 13:30).',
    ]);
  });

  it('rejects zero, negative and non-numeric durations', () => {
    const expected = ['Duration must be a positive number of minutes.'];
    expect(errorsOf(evaluate('10:00', 0, room, NOW))).toEqual(expected);
    expect(errorsOf(evaluate('10:00', -30, room, NOW))).toEqual(expected);
    expect(errorsOf(evaluate('10:00', NaN, room, NOW))).toEqual(expected);
  });

  it('rejects fractional durations', () => {
    expect(errorsOf(evaluate('10:00', 60.5, room, NOW))).toEqual([
      'Duration must be a whole number of minutes.',
    ]);
  });

  it('allows the maximum duration and rejects anything above it', () => {
    const empty = makeRoom({ bookings: [] });
    expect(evaluate('10:00', 120, empty, NOW).kind).toBe('available');
    expect(errorsOf(evaluate('10:00', 121, empty, NOW))).toEqual([
      'Duration must not exceed 120 minutes.',
    ]);
  });

  it('reports every input problem together', () => {
    expect(errorsOf(evaluate('nope', 0, room, NOW))).toHaveLength(2);
  });
});

describe('evaluate: time rules', () => {
  const room = makeRoom();

  it('rejects a start equal to the current time', () => {
    expect(errorsOf(evaluate('08:20', 60, room, NOW))).toEqual([
      'Start must be strictly after the current time (08:20).',
    ]);
  });

  it('rejects a start before the current time', () => {
    expect(errorsOf(evaluate('08:00', 60, room, NOW))).toEqual([
      'Start must be strictly after the current time (08:20).',
    ]);
  });

  it('accepts a start one minute after the current time', () => {
    expect(evaluate('08:21', 60, makeRoom({ bookings: [] }), NOW).kind).toBe('available');
  });

  it('allows a booking that ends exactly at midnight', () => {
    expect(evaluate('23:00', 60, room, NOW).kind).toBe('available');
    expect(evaluate('22:00', 120, room, NOW).kind).toBe('available');
  });

  it('rejects a booking that runs past midnight', () => {
    expect(errorsOf(evaluate('22:01', 120, room, NOW))).toEqual([
      'Booking would run past midnight (24:00). Choose an earlier start or shorter duration.',
    ]);
  });
});

describe('evaluate: room availability', () => {
  it('returns available for a free slot with the computed range', () => {
    expect(evaluate('10:00', 60, makeRoom(), NOW)).toEqual({
      kind: 'available',
      start: 600,
      end: 660,
    });
  });

  it('accepts a slot that starts exactly when another booking ends', () => {
    expect(evaluate('10:00', 60, makeRoom(), NOW).kind).toBe('available');
  });

  it('reports the conflicting booking when a slot overlaps', () => {
    const room = makeRoom();
    const verdict = evaluate('09:30', 60, room, NOW);
    expect(verdict).toEqual({
      kind: 'unavailable',
      reason: 'Overlaps an existing booking: "Calculus II" (09:00–10:00).',
      conflictingBooking: room.bookings[0],
    });
  });

  it('reports a blocked room with its custom reason', () => {
    const room = makeRoom({ blocked: true, blockedReason: 'Under maintenance' });
    expect(evaluate('10:00', 60, room, NOW)).toEqual({
      kind: 'unavailable',
      reason: 'Under maintenance',
    });
  });

  it('reports a blocked room with the default reason when none is given', () => {
    const room = makeRoom({ blocked: true });
    expect(evaluate('10:00', 60, room, NOW)).toEqual({
      kind: 'unavailable',
      reason: 'This room is currently blocked and cannot be booked.',
    });
  });

  it('does not mutate the room or its bookings', () => {
    const room = deepFreeze(makeRoom());
    const snapshot = structuredClone(room);
    evaluate('09:30', 60, room, NOW);
    evaluate('10:00', 60, room, NOW);
    expect(room).toEqual(snapshot);
  });
});
