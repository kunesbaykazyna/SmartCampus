import type { Room } from '@/lib/booking';

export type FilterCriteria = {
  minCapacity: number;
  requiredEquipment: string[];
};

export const filterByCapacity = (
  rooms: readonly Room[],
  minCapacity: number,
): Room[] => rooms.filter((r) => r.capacity >= minCapacity);

export const filterByEquipment = (
  rooms: readonly Room[],
  required: readonly string[],
): Room[] => {
  if (required.length === 0) return [...rooms];
  return rooms.filter((r) => required.every((item) => r.equipment.includes(item)));
};

// F3 is enforced centrally: a blocked room is never returned by the combined filter.
export const filterOutBlocked = (rooms: readonly Room[]): Room[] =>
  rooms.filter((r) => !r.blocked);

export const filterRooms = (
  rooms: readonly Room[],
  criteria: FilterCriteria,
): Room[] => {
  const byCapacity = filterByCapacity(rooms, criteria.minCapacity);
  const byEquipment = filterByEquipment(byCapacity, criteria.requiredEquipment);
  return filterOutBlocked(byEquipment);
};

export const findRoomById = (
  rooms: readonly Room[],
  id: string,
): Room | undefined => rooms.find((r) => r.id === id);
