import type { Room } from '@/lib/booking';

export const ROOMS: Room[] = [
  {
    id: 'room-a301',
    name: 'Room A301',
    building: 'Engineering Block, Floor 3',
    capacity: 32,
    type: 'Lecture Hall',
    equipment: ['Projector', 'Microphone', 'Whiteboard'],
    blocked: false,
    imageUrl:
      'https://images.pexels.com/photos/36834057/pexels-photo-36834057.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    bookings: [
      { id: 'a301-b1', title: 'Calculus II', organizer: 'Prof. Tan', start: 540, end: 600 },
      { id: 'a301-b2', title: 'Faculty Sync', organizer: 'Dean Office', start: 660, end: 720 },
      { id: 'a301-b3', title: 'Robotics Lab', organizer: 'Prof. Lim', start: 780, end: 840 },
      { id: 'a301-b4', title: 'Study Group', organizer: 'ACM Chapter', start: 900, end: 960 },
    ],
  },
  {
    id: 'room-b204',
    name: 'Room B204',
    building: 'Science Block, Floor 2',
    capacity: 16,
    type: 'Seminar Room',
    equipment: ['Whiteboard', 'Smart TV'],
    blocked: false,
    imageUrl:
      'https://images.pexels.com/photos/31107325/pexels-photo-31107325.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    bookings: [
      { id: 'b204-b1', title: 'Research Seminar', organizer: 'Prof. Okafor', start: 540, end: 600 },
      { id: 'b204-b2', title: 'Journal Club', organizer: 'Dr. Reyes', start: 720, end: 780 },
    ],
  },
  {
    id: 'room-c110',
    name: 'Room C110',
    building: 'IT Block, Floor 1',
    capacity: 24,
    type: 'Computer Lab',
    equipment: ['Projector', 'Desktop PCs', 'Smart TV'],
    blocked: true,
    blockedReason: 'Network upgrade in progress',
    imageUrl:
      'https://images.pexels.com/photos/39178037/pexels-photo-39178037.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    bookings: [
      { id: 'c110-b1', title: 'Web Dev Workshop', organizer: 'Prof. Chen', start: 600, end: 660 },
    ],
  },
  {
    id: 'room-d007',
    name: 'Room D007',
    building: 'Library Block, Ground Floor',
    capacity: 8,
    type: 'Study Room',
    equipment: ['Whiteboard'],
    blocked: false,
    imageUrl:
      'https://images.pexels.com/photos/5905445/pexels-photo-5905445.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    bookings: [
      { id: 'd007-b1', title: 'Thesis Prep', organizer: 'Senior Cohort', start: 840, end: 900 },
      { id: 'd007-b2', title: 'Peer Tutoring', organizer: 'Student Union', start: 960, end: 1020 },
    ],
  },
];
