export type Booking = {
  id: string;
  title: string;
  organizer: string;
  start: number; // minutes after midnight
  end: number; // minutes after midnight (exclusive)
};

export type Room = {
  id: string;
  name: string;
  building: string;
  capacity: number;
  type: string;
  equipment: string[];
  blocked: boolean;
  blockedReason?: string;
  imageUrl: string;
  bookings: Booking[];
};

export const MIN_STEP = 5;
export const MAX_DURATION = 120;
export const SLOT_DURATION = 60;
export const DAY_MINUTES = 1440;

export type ValidationResult = {
  isValid: boolean;
  error?: string;
};

export const toClock = (mins: number): string => {
  const h = Math.floor(mins / 60);
  const m = mins % 60;
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
};

export const fromClock = (text: string): number | null => {
  const match = /^([01]?\d|2[0-3]):([0-5]\d)$/.exec(text.trim());
  if (!match) return null;
  return parseInt(match[1], 10) * 60 + parseInt(match[2], 10);
};

export const validateStart = (startInput: string): ValidationResult => {
  if (fromClock(startInput) === null) {
    return {
      isValid: false,
      error: 'Start time must be in 24-hour HH:MM format (e.g. 13:30).',
    };
  }
  return { isValid: true };
};

export const validateDuration = (duration: number): ValidationResult => {
  if (!Number.isFinite(duration) || duration <= 0) {
    return { isValid: false, error: 'Duration must be a positive number of minutes.' };
  }
  if (duration % 1 !== 0) {
    return { isValid: false, error: 'Duration must be a whole number of minutes.' };
  }
  if (duration > MAX_DURATION) {
    return { isValid: false, error: `Duration must not exceed ${MAX_DURATION} minutes.` };
  }
  return { isValid: true };
};

export const findConflict = (
  bookings: readonly Booking[],
  start: number,
  end: number,
): Booking | undefined => {
  // Touching endpoints do NOT overlap: [a,b) vs [c,d) -> a < d && c < b
  return bookings.find((b) => start < b.end && b.start < end);
};

export type Verdict =
  | { kind: 'idle' }
  | { kind: 'error'; messages: string[] }
  | { kind: 'unavailable'; reason: string; conflictingBooking?: Booking }
  | { kind: 'available'; start: number; end: number };

export const evaluate = (
  startInput: string,
  duration: number,
  room: Room,
  now: number,
): Verdict => {
  const errors: string[] = [];

  const startCheck = validateStart(startInput);
  if (!startCheck.isValid && startCheck.error) errors.push(startCheck.error);

  const durationCheck = validateDuration(duration);
  if (!durationCheck.isValid && durationCheck.error) errors.push(durationCheck.error);

  if (errors.length > 0) {
    return { kind: 'error', messages: errors };
  }

  // From here start and duration are known-good integers.
  const s = fromClock(startInput) as number;
  const end = s + duration;

  if (end > DAY_MINUTES) {
    errors.push('Booking would run past midnight (24:00). Choose an earlier start or shorter duration.');
  }
  if (s <= now) {
    errors.push(`Start must be strictly after the current time (${toClock(now)}).`);
  }

  if (errors.length > 0) {
    return { kind: 'error', messages: errors };
  }

  if (room.blocked) {
    return {
      kind: 'unavailable',
      reason: room.blockedReason ?? 'This room is currently blocked and cannot be booked.',
    };
  }

  const conflict = findConflict(room.bookings, s, end);
  if (conflict) {
    return {
      kind: 'unavailable',
      reason: `Overlaps an existing booking: "${conflict.title}" (${toClock(conflict.start)}–${toClock(conflict.end)}).`,
      conflictingBooking: conflict,
    };
  }

  return { kind: 'available', start: s, end };
};
