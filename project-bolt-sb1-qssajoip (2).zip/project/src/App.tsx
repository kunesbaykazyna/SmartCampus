import { useEffect, useMemo, useState } from 'react';
import {
  CheckCircle2,
  XCircle,
  Clock,
  DoorClosed,
  CalendarDays,
  Timer,
  AlertTriangle,
  Building2,
  Users,
  Sun,
  Moon,
  Search,
  RotateCcw,
  Filter,
  Cpu,
} from 'lucide-react';
import {
  DAY_MINUTES,
  MAX_DURATION,
  MIN_STEP,
  SLOT_DURATION,
  evaluate,
  findConflict,
  toClock,
  type Room,
  type Verdict,
} from '@/lib/booking';
import { ROOMS } from '@/lib/rooms';
import { filterRooms, findRoomById, type FilterCriteria } from '@/lib/filtering';

const NOW_MINUTES = 500; // 08:20 AM

const ALL_EQUIPMENT = Array.from(
  new Set(ROOMS.flatMap((r) => r.equipment)),
).sort();

const describeTimeOfDay = (mins: number): { label: string; Icon: typeof Sun } => {
  if (mins < 720) return { label: 'Morning', Icon: Sun };
  if (mins < 1080) return { label: 'Afternoon', Icon: Sun };
  return { label: 'Evening', Icon: Moon };
};

const DEFAULT_DURATION = '60';

const App = () => {
  const [minCapacity, setMinCapacity] = useState(0);
  const [requiredEquipment, setRequiredEquipment] = useState<string[]>([]);
  const [selectedRoomId, setSelectedRoomId] = useState<string>(ROOMS[0].id);
  const [startInput, setStartInput] = useState('');
  const [durationInput, setDurationInput] = useState(DEFAULT_DURATION);
  const [now] = useState(NOW_MINUTES);
  const [submitted, setSubmitted] = useState(false);

  const criteria = useMemo<FilterCriteria>(
    () => ({ minCapacity, requiredEquipment }),
    [minCapacity, requiredEquipment],
  );

  const visibleRooms = useMemo(() => filterRooms(ROOMS, criteria), [criteria]);

  // F5: when filters change, keep the selected room only if it is still visible.
  useEffect(() => {
    if (!visibleRooms.some((r) => r.id === selectedRoomId)) {
      setSelectedRoomId(visibleRooms[0]?.id ?? '');
    }
  }, [visibleRooms, selectedRoomId]);

  const selectedRoom: Room | undefined = useMemo(
    () => findRoomById(ROOMS, selectedRoomId),
    [selectedRoomId],
  );

  const duration = parseInt(durationInput, 10);
  const verdict = useMemo<Verdict>(() => {
    if (!submitted || !selectedRoom) return { kind: 'idle' };
    return evaluate(startInput, duration, selectedRoom, now);
  }, [submitted, selectedRoom, startInput, duration, now]);

  const handleReset = () => {
    setStartInput('');
    setDurationInput(DEFAULT_DURATION);
    setSubmitted(false);
  };

  // F5: selecting a new room re-runs the availability check against that room's bookings.
  const handleSelectRoom = (id: string) => {
    setSelectedRoomId(id);
    setSubmitted(false);
  };

  const toggleEquipment = (item: string) => {
    setRequiredEquipment((prev) =>
      prev.includes(item) ? prev.filter((x) => x !== item) : [...prev, item],
    );
    setSubmitted(false);
  };

  const tod = describeTimeOfDay(now);

  // Quick-pick list of the next few free start slots for the selected room.
  const quickPicks = useMemo(() => {
    if (!selectedRoom) return [];
    const picks: { start: number; end: number }[] = [];
    for (let s = Math.ceil((now + 1) / MIN_STEP) * MIN_STEP; s <= DAY_MINUTES - 30; s += MIN_STEP) {
      const end = s + SLOT_DURATION;
      if (end > DAY_MINUTES) continue;
      if (!findConflict(selectedRoom.bookings, s, end)) {
        picks.push({ start: s, end });
      }
      if (picks.length >= 4) break;
    }
    return picks;
  }, [now, selectedRoom]);

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900">
      <div className="mx-auto max-w-4xl px-4 py-6 sm:py-10">
        {/* Header */}
        <header className="mb-6 flex items-center gap-3">
          <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-emerald-600 text-white shadow-sm">
            <Building2 size={22} />
          </div>
          <div>
            <h1 className="text-xl font-semibold leading-tight sm:text-2xl">
              Smart Campus Room Availability
            </h1>
            <p className="text-sm text-slate-500">
              Filter rooms and check a time slot — no booking is created.
            </p>
          </div>
        </header>

        {/* Filters */}
        <section className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm sm:p-5">
          <h3 className="mb-3 flex items-center gap-1.5 text-sm font-semibold text-slate-700">
            <Filter size={15} /> Filter rooms
          </h3>

          <div className="grid gap-4 sm:grid-cols-2">
            <label className="block">
              <span className="mb-1 flex items-center gap-1.5 text-xs font-medium text-slate-600">
                <Users size={14} /> Minimum capacity
              </span>
              <input
                type="number"
                min={0}
                value={minCapacity}
                onChange={(e) => {
                  setMinCapacity(Math.max(0, parseInt(e.target.value, 10) || 0));
                  setSubmitted(false);
                }}
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm outline-none transition focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100"
              />
            </label>

            <div>
              <span className="mb-1 flex items-center gap-1.5 text-xs font-medium text-slate-600">
                <Cpu size={14} /> Required equipment
              </span>
              <div className="flex flex-wrap gap-2">
                {ALL_EQUIPMENT.map((item) => {
                  const active = requiredEquipment.includes(item);
                  return (
                    <button
                      key={item}
                      type="button"
                      onClick={() => toggleEquipment(item)}
                      className={`rounded-full border px-3 py-1 text-xs font-medium transition ${
                        active
                          ? 'border-emerald-500 bg-emerald-50 text-emerald-700'
                          : 'border-slate-200 bg-slate-50 text-slate-600 hover:border-emerald-300'
                      }`}
                    >
                      {item}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          <p className="mt-3 text-xs text-slate-500">
            {visibleRooms.length} of {ROOMS.length} rooms match
          </p>
        </section>

        {/* Room selector */}
        <section className="mt-5 rounded-2xl border border-slate-200 bg-white p-4 shadow-sm sm:p-5">
          <h3 className="mb-3 text-sm font-semibold text-slate-700">Choose a room</h3>

          {visibleRooms.length === 0 ? (
            <div className="rounded-xl border border-dashed border-slate-200 bg-slate-50 p-6 text-center text-sm text-slate-400">
              No rooms match your filters. Try lowering the capacity or removing equipment
              requirements.
            </div>
          ) : (
            <div className="grid gap-2 sm:grid-cols-2">
              {visibleRooms.map((room) => {
                const selected = room.id === selectedRoomId;
                return (
                  <button
                    key={room.id}
                    type="button"
                    onClick={() => handleSelectRoom(room.id)}
                    className={`flex items-center justify-between rounded-xl border px-4 py-3 text-left transition ${
                      selected
                        ? 'border-emerald-500 bg-emerald-50 ring-1 ring-emerald-200'
                        : 'border-slate-200 bg-white hover:border-emerald-300'
                    }`}
                  >
                    <div>
                      <p className="text-sm font-semibold text-slate-800">{room.name}</p>
                      <p className="text-xs text-slate-500">{room.building}</p>
                    </div>
                    <div className="text-right text-xs text-slate-500">
                      <p className="flex items-center gap-1">
                        <Users size={12} /> {room.capacity}
                      </p>
                      <p className="mt-0.5">{room.type}</p>
                    </div>
                  </button>
                );
              })}
            </div>
          )}
        </section>

        {/* Room card */}
        {selectedRoom && (
          <section className="mt-5 overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
            <div className="relative h-40 w-full sm:h-52">
              <img
                src={selectedRoom.imageUrl}
                alt={selectedRoom.name}
                className="h-full w-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-900/70 to-transparent" />
              <div className="absolute bottom-3 left-4 right-4 flex items-end justify-between gap-3">
                <div>
                  <h2 className="text-lg font-semibold text-white sm:text-xl">
                    {selectedRoom.name}
                  </h2>
                  <p className="flex items-center gap-1 text-sm text-white/85">
                    <DoorClosed size={14} /> {selectedRoom.building}
                  </p>
                </div>
                <span
                  className={`inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-medium ${
                    selectedRoom.blocked
                      ? 'bg-rose-500/90 text-white'
                      : 'bg-emerald-500/90 text-white'
                  }`}
                >
                  {selectedRoom.blocked ? <XCircle size={13} /> : <CheckCircle2 size={13} />}
                  {selectedRoom.blocked ? 'Blocked' : 'Open'}
                </span>
              </div>
            </div>

            <div className="grid grid-cols-3 divide-x divide-slate-100 border-t border-slate-100 text-center">
              <div className="px-2 py-3">
                <p className="text-[11px] uppercase tracking-wide text-slate-400">Type</p>
                <p className="text-sm font-medium">{selectedRoom.type}</p>
              </div>
              <div className="px-2 py-3">
                <p className="text-[11px] uppercase tracking-wide text-slate-400">Capacity</p>
                <p className="flex items-center justify-center gap-1 text-sm font-medium">
                  <Users size={14} /> {selectedRoom.capacity}
                </p>
              </div>
              <div className="px-2 py-3">
                <p className="text-[11px] uppercase tracking-wide text-slate-400">Now</p>
                <p className="flex items-center justify-center gap-1 text-sm font-medium">
                  <tod.Icon size={14} /> {toClock(now)}
                </p>
              </div>
            </div>

            <div className="border-t border-slate-100 px-4 py-3">
              <p className="text-[11px] uppercase tracking-wide text-slate-400">Equipment</p>
              <div className="mt-1.5 flex flex-wrap gap-1.5">
                {selectedRoom.equipment.map((item) => (
                  <span
                    key={item}
                    className="rounded-md bg-slate-100 px-2 py-0.5 text-xs font-medium text-slate-600"
                  >
                    {item}
                  </span>
                ))}
              </div>
            </div>
          </section>
        )}

        {/* Form */}
        {selectedRoom && (
          <section className="mt-5 rounded-2xl border border-slate-200 bg-white p-4 shadow-sm sm:p-5">
            <h3 className="mb-3 text-sm font-semibold text-slate-700">
              Check a candidate time
            </h3>

            <div className="grid gap-3 sm:grid-cols-2">
              <label className="block">
                <span className="mb-1 flex items-center gap-1.5 text-xs font-medium text-slate-600">
                  <Clock size={14} /> Start time (HH:MM, 24h)
                </span>
                <input
                  type="text"
                  autoComplete="off"
                  placeholder="10:00"
                  value={startInput}
                  onChange={(e) => setStartInput(e.target.value)}
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm outline-none transition focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100"
                />
              </label>

              <label className="block">
                <span className="mb-1 flex items-center gap-1.5 text-xs font-medium text-slate-600">
                  <Timer size={14} /> Duration (minutes, max {MAX_DURATION})
                </span>
                <input
                  type="number"
                  min={1}
                  max={MAX_DURATION}
                  step={5}
                  value={durationInput}
                  onChange={(e) => setDurationInput(e.target.value)}
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm outline-none transition focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100"
                />
              </label>
            </div>

            {/* Quick picks */}
            <div className="mt-3">
              <p className="mb-1.5 text-xs font-medium text-slate-600">
                Next free 60-min slots
              </p>
              <div className="flex flex-wrap gap-2">
                {quickPicks.length === 0 && (
                  <p className="text-xs text-slate-400">No free 60-min slots remain today.</p>
                )}
                {quickPicks.map((p) => (
                  <button
                    key={p.start}
                    type="button"
                    onClick={() => {
                      setStartInput(toClock(p.start));
                      setDurationInput(DEFAULT_DURATION);
                      setSubmitted(false);
                    }}
                    className="rounded-full border border-slate-200 bg-slate-50 px-3 py-1 text-xs font-medium text-slate-700 transition hover:border-emerald-400 hover:bg-emerald-50 hover:text-emerald-700"
                  >
                    {toClock(p.start)}
                  </button>
                ))}
              </div>
            </div>

            {/* Actions */}
            <div className="mt-4 flex flex-col gap-2 sm:flex-row">
              <button
                type="button"
                onClick={() => setSubmitted(true)}
                className="inline-flex flex-1 items-center justify-center gap-2 rounded-lg bg-emerald-600 px-4 py-2.5 text-sm font-semibold text-white shadow-sm transition hover:bg-emerald-700 focus:outline-none focus:ring-2 focus:ring-emerald-300 active:scale-[0.99]"
              >
                <Search size={16} /> Check Availability
              </button>
              <button
                type="button"
                onClick={handleReset}
                className="inline-flex items-center justify-center gap-2 rounded-lg border border-slate-300 bg-white px-4 py-2.5 text-sm font-medium text-slate-700 transition hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-slate-200 active:scale-[0.99]"
              >
                <RotateCcw size={16} /> Reset
              </button>
            </div>
          </section>
        )}

        {/* Result */}
        {selectedRoom && (
          <section className="mt-4">
            <VerdictPanel verdict={verdict} />
          </section>
        )}

        {/* Day schedule (read-only, not mutated) */}
        {selectedRoom && (
          <section className="mt-5 rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
            <h3 className="mb-2 flex items-center gap-1.5 text-sm font-semibold text-slate-700">
              <CalendarDays size={15} /> Today's schedule — {selectedRoom.name}
            </h3>
            {selectedRoom.bookings.length === 0 ? (
              <p className="py-2 text-sm text-slate-400">No bookings today.</p>
            ) : (
              <ul className="divide-y divide-slate-100">
                {selectedRoom.bookings.map((b) => (
                  <li key={b.id} className="flex items-center justify-between py-2 text-sm">
                    <div>
                      <p className="font-medium text-slate-800">{b.title}</p>
                      <p className="text-xs text-slate-500">by {b.organizer}</p>
                    </div>
                    <span className="rounded-md bg-slate-100 px-2 py-0.5 font-mono text-xs text-slate-600">
                      {toClock(b.start)}–{toClock(b.end)}
                    </span>
                  </li>
                ))}
              </ul>
            )}
            <p className="mt-2 text-xs text-slate-400">
              Reference only — checking availability never changes this list.
            </p>
          </section>
        )}
      </div>
    </div>
  );
};

const VerdictPanel: React.FC<{ verdict: Verdict }> = ({ verdict }) => {
  if (verdict.kind === 'idle') {
    return (
      <div className="rounded-2xl border border-dashed border-slate-200 bg-white p-4 text-center text-sm text-slate-400">
        Fill in a start time and duration, then press “Check Availability”.
      </div>
    );
  }

  if (verdict.kind === 'error') {
    return (
      <div className="rounded-2xl border border-amber-200 bg-amber-50 p-4">
        <div className="flex items-start gap-2 text-amber-800">
          <AlertTriangle size={18} className="mt-0.5 shrink-0" />
          <div>
            <p className="text-sm font-semibold">Please fix the following:</p>
            <ul className="mt-1 list-disc space-y-0.5 pl-4 text-sm">
              {verdict.messages.map((m) => (
                <li key={m}>{m}</li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    );
  }

  if (verdict.kind === 'unavailable') {
    return (
      <div className="rounded-2xl border border-rose-200 bg-rose-50 p-4">
        <div className="flex items-start gap-2 text-rose-800">
          <XCircle size={20} className="mt-0.5 shrink-0" />
          <div>
            <p className="text-sm font-semibold">Unavailable</p>
            <p className="text-sm">{verdict.reason}</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="rounded-2xl border border-emerald-200 bg-emerald-50 p-4">
      <div className="flex items-start gap-2 text-emerald-800">
        <CheckCircle2 size={20} className="mt-0.5 shrink-0" />
        <div>
          <p className="text-sm font-semibold">Available</p>
          <p className="text-sm">
            {toClock(verdict.start)}–{toClock(verdict.end)} (
            {verdict.end - verdict.start} min) is free.
          </p>
        </div>
      </div>
    </div>
  );
};

export default App;
