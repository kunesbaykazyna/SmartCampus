# Project

Smart Campus room availability checker built with React.

The application checks whether one room is available using fictional booking data.

# Constraints

- Preserve all existing booking behavior.
- Preserve AC1–AC6.
- Keep the existing UI and responsive design.
- Do not add a backend, database or login.
- Do not add booking creation or saving.

# Engineering Rules

- Prefer simple pure functions.
- Separate booking validation from UI logic.
- Avoid unnecessary design patterns.
- Do not mutate booking fixtures.
- Make minimal changes.

# Verification

- Add regression tests for booking rules.
- Run all available tests.
- Report all changed and created files.
- Explain the refactoring.
- Provide exact test results.